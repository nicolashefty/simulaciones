/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objects;

/**
 *
 * @author federico
 */
public class Exponencial {
    private double media;
    private double lambda;

    public Exponencial(double media) {
        this.media = media;
        this.lambda = 1/media;
    }

    public double getMedia() {
        return media;
    }

    public void setMedia(double media) {
        this.media = media;
    }

    public double getLambda() {
        return lambda;
    }

    public void setLambda(double media) {
        this.lambda = 1/media;
    }
    
}
