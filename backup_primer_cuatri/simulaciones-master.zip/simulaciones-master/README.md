# simulaciones
Repo para los tps de simulaciones
